---
pokemon:
  name: "Pokémon #959"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/959.png
---
