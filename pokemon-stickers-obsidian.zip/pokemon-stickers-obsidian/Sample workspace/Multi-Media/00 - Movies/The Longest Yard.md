---
title: The Longest Yard
genre: comedy
where_to_watch: unknown
seen: true
tags: movies, comedy
created: 2025-03-14
good: true
pokemon:
  name: "Pokémon #650"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/650.png
---
**🎬 Movie Name:** The Longest Yard  
**📌 Genre:** [[Comedy]]
**📺 Where to Watch:** [[Unknown]]
**✅ Seen It?** true  

**📝 Notes:**  
-
