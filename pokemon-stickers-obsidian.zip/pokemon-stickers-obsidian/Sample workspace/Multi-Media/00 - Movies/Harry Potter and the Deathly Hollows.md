---
title: Harry Potter and the Deathly Hollows
genre: fantasy
where_to_watch: Max
seen: true
tags: movie, fantasy
created: 2025-03-14
pokemon:
  name: "Pokémon #380"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/380.png
---
**🎬 Movie Name:** Harry Potter and the Deathly Hollows  
**📌 Genre:** [[Fantasy]]
**📺 Where to Watch:** Max  
**✅ Seen It?** true  

**📝 Notes:**  
-
