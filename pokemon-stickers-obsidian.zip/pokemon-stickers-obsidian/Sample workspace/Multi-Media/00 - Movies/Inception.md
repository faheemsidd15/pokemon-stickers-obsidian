---
title: Inception
genre: thriller
where_to_watch: unknown
seen: yes
tags:
  - movie
  - thriller
created: 2025-03-14
pokemon:
  name: "Pokémon #55"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/55.png
---

**🎬 Movie Name:** Inception  
**📌 Genre:** [[Thriller]]  
**📺 Where to Watch:** [[Unknown]]  
**✅ Seen It?** yes  

**📝 Notes:**  
-
