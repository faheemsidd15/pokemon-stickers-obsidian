---
title: Exorcist
genre: horror
where_to_watch: unknown
seen: true
tags: movie, horror
created: 2025-03-14
good: true
pokemon:
  name: "Pokémon #395"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/395.png
---
**🎬 Movie Name:** Exorcist  
**📌 Genre:** [[Horror]]  
**📺 Where to Watch:** unknown  
**✅ Seen It?**   

**📝 Notes:**  
-
