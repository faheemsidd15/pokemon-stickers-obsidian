---
title: Pushpa
genre: south-indian
where_to_watch: netflix, prime
seen: yes
tags: movie, must-watch, south-indian
pokemon:
  name: "Pokémon #1022"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1022.png
---


---

**🎬 Movie Name:** Pushpa  
**📌 Genre:** [[South-indian]] 
**📺 Where to Watch:** [[Netflix]], [[Prime]]  
**✅ Seen It?** yes  

**📝 Notes:**  
- 
