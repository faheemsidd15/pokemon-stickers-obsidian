---
title: Dodgeball
genre: Comedy
where_to_watch: Unknown
seen: true
tags: movie, Comedy
created: 2025-03-17
pokemon:
  name: "Pokémon #630"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/630.png
---
**🎬 Movie Name:** Dodgeball  
**📌 Genre:** [[Comedy]]
**📺 Where to Watch:** [[Unknown]]

**✅ Seen It?** true  

**📝 Notes:**  
-
