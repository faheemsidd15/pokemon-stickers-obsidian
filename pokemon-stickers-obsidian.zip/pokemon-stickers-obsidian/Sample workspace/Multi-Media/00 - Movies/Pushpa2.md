---
title: Pushpa2
genre: south-indian
where_to_watch: prime
seen: yes
tags:
  - movie
  - must-watch
  - south-indian
created: 2025-03-14
pokemon:
  name: "Pokémon #93"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/93.png
---


**🎬 Movie Name:** Pushpa2  
**📌 Genre:** [[South-indian]]  
**📺 Where to Watch:** [[Prime]]  
**✅ Seen It?** yes  

**📝 Notes:**  
- 
