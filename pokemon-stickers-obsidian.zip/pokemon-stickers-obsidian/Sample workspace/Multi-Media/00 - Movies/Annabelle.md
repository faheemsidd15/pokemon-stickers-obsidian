---
title: Annabelle
genre: horror
where_to_watch: unknown
seen: true
tags: movie, horror
created: 2025-03-14
pokemon:
  name: "Pokémon #362"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/362.png
---
**🎬 Movie Name:** Annabelle  
**📌 Genre:** [[Horror]]
**📺 Where to Watch:** unknown  
**✅ Seen It?** true  

**📝 Notes:**  
-
