---
title: The Notebook
genre: romantic
where_to_watch: unknown
seen: true
tags: movie, romantic
created: 2025-03-14
pokemon:
  name: "Pokémon #443"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/443.png
---
**🎬 Movie Name:** The Notebook  
**📌 Genre:** [[Romantic]]
**📺 Where to Watch:** Unknown

**✅ Seen It?** true  

**📝 Notes:**  
-
