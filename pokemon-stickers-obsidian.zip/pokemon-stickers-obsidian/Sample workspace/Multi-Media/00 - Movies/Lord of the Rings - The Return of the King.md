---
title: Lord of the Rings - The Return of the King
genre: Fantasy, Adventure
where_to_watch: Max
seen: true
tags: movie, Fantasy, Adventure
created: 2025-03-16
pokemon:
  name: "Pokémon #514"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/514.png
---
**🎬 Movie Name:** Lord of the Rings - The Return of the King  
**📌 Genre:** [[Fantasy, Adventure]]
**📺 Where to Watch:** [[Max]]

**✅ Seen It?** true  

**📝 Notes:**  
-
