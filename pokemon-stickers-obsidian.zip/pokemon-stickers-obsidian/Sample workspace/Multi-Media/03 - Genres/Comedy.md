---
tags: genre
pokemon:
  name: "Pokémon #393"
  image: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/393.png
---


```dataview
TABLE seen, good
FROM "00 - Movies"
WHERE  contains(genre, "comedy")
SORT created DESC
```
